import OpenAI from "openai";
const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export default async function handler(req, res) {
  try {
    const { answers, counts } = req.body;
    const text = answers.map(a => `${a.title}：${a.type}`).join("\n");
    const prompt = `你是一个哲学心理分析师，请根据以下答题内容写一个灵魂总结：
${text}
类型分布：${JSON.stringify(counts)}
要求：富有诗意和哲理。`;

    const completion = await client.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [{ role: "user", content: prompt }]
    });
    const result = completion.choices[0].message.content;

    res.status(200).json({ summaryTitle: "灵魂总结", summaryText: result });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}
